from setuptools import setup, find_packages

setup(
    name='paperlib',
    version='0.8',
    packages=find_packages(),
)
