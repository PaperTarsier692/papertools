from setuptools import setup, find_packages

setup(
    name='papertools',
    version='0.8',
    packages=find_packages(),
)
